#!/bin/bash
sudo telinit 3