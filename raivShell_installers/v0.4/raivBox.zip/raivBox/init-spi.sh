#!/bin/bash
sudo modprobe spidev