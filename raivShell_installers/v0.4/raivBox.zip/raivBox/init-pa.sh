#!/bin/bash
pacmd set-default-sink 0
pacmd set-default-source 1